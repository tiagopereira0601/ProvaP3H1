﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova2Bim.Dominio.Entidades
{
    public class Jogo
    {
        public object Id;

        public int IdJogo { get; set; }     

        public int Valor1 { get; set; }
        public int Valor2 { get; set; }
        public int Valor3 { get; set; }
        public int Valor4 { get; set; }
        public int Valor5 { get; set; }
        public int Valor6 { get; set; }
        public DateTime DataJogo { get; set; }

    }
}
