﻿using Microsoft.AspNetCore.Mvc;
using Prova2Bim.Dominio.Entidades;

namespace Prova2Bim.API.Controllers
{
    public class JogoController : Controller
    {
        [ApiController]
        [Route("api/[controller]")]
        public class  ControllerBase { } 

            private readonly IJogoService _service; 

            public JogoController(IJogoService service) { _service = service; }

        public IJogoService Get_service()
        {
            return _service;
        }

        [HttpPost]
        public IActionResult Criar(Jogo r, IJogoService _service) {Criar(r); return CreatedAtAction(nameof(BuscarPorId), new { id = r.Id }, r); }

        private void Criar(Jogo r)
        {
            throw new NotImplementedException();
        }

        private object BuscarPorId()
        {
            throw new NotImplementedException();
        }

        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(Listar());
        }
    }

    }

