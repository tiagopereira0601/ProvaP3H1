using Prova2Bim.Data.Repositorio;

var builder = WebApplication.CreateBuilder(args);

object value = builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer("StringDeConexao"));


builder.Services.AddScoped<IJogoRepository, JogoRepository>(); 
builder.Services.AddScoped<IJogoService, JogoService>();       
builder.Services.AddControllers();

var app = builder.Build();

app.MapControllers();

app.Run();


