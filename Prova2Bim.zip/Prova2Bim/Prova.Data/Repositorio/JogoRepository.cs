﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   
using System.Linq;


namespace Prova2Bim.Data.Repositorio
{


    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base (options) { } 
        public DbSet<Jogo> Jogos { get; set; }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }

        public class DbContextOptions<T>
        {
        }
    }

    public class DbContext
    {
        private AppDbContext.DbContextOptions<AppDbContext> options;

        public DbContext(AppDbContext.DbContextOptions<AppDbContext> options)
        {
            this.options = options;
        }
    }

    public class DbSet<T>
    {
        internal List<Jogo> ToList()
        {
            throw new NotImplementedException();
        }

        internal void Add(Jogo r)
        {
            throw new NotImplementedException();
        }
    }

    public class JogoRepository : IJogoRepository 
    {
        private readonly AppDbContext _context; 

        public JogoRepository(AppDbContext context) { _context = context; } 

        public List<Jogo> Listar() => _context.Jogos.ToList(); 

        public void Criar(Jogo r) { _context.Jogos.Add(r); _context.SaveChanges(); }
      }

    public class Jogo
    {
    }
}