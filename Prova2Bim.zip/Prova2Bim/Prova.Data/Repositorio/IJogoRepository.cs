﻿namespace Prova2Bim.Data.Repositorio
{
    public interface IJogoRepository
    {
        List<Jogo> Listar();
        void Criar(Jogo j);
    }
}