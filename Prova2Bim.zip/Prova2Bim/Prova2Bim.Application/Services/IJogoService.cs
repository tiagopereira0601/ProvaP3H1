﻿using Prova2Bim.Dominio.Entidades;
using System.Collections.Generic;

public interface IJogoService 
{
    List<Jogo> Listar();

    void Criar(Jogo j);
   
}

