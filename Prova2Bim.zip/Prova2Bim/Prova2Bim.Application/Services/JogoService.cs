﻿using Prova2Bim.Data.Repositorio;
using Prova2Bim.Dominio.Entidades;

public class JogoService : IJogoService 
{
    private readonly IJogoRepository _repository; 

    public JogoService(IJogoRepository repository) { _repository = repository; } 

    public List<Prova2Bim.Data.Repositorio.Jogo> Listar() => _repository.Listar();

    
    public void Criar(Prova2Bim.Data.Repositorio.Jogo j) => _repository.Criar(j);

    List<Prova2Bim.Dominio.Entidades.Jogo> IJogoService.Listar()
    {
        throw new NotImplementedException();
    }

    public void Criar(Prova2Bim.Dominio.Entidades.Jogo j)
    {
        throw new NotImplementedException();
    }
}